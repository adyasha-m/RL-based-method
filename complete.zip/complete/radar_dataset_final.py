import csv
import random
import pygame
import math
from datetime import datetime, timedelta

# --- Configuration for Data Generation ---
NUM_UNIQUE_TRACKED_TARGETS = 50 # Number of distinct targets to simulate with full progression
NUM_STANDALONE_SEARCH_TASKS = 180 # Number of search tasks not tied to full progression

# Maximum number of times a target can be processed for each specific stage.
# This ensures we generate enough tasks for a target to 'qualify' for the next stage.
MAX_STAGES_PER_TARGET_TYPE = {
    'Search': 1,         # 1 Search task is enough to potentially move to Detection
    'Detection': 4,      # Need 4 Detection tasks to move to Tracking
    'Tracking': 5,       # Need 5 Tracking tasks to move to Classification
    'Classification': 6  # Need 6 Classification tasks for 'Target Locked'
}
# Define the order of progression
STAGE_ORDER = ['Search', 'Detection', 'Tracking', 'Classification', 'Locked']

# Radar capabilities: Which tasks each radar can perform
RADAR_CAPABILITIES = {
    'R1': ['Search', 'Detection', 'Classification'],
    'R2': ['Classification', 'Tracking', 'Detection'],
    'R3': ['Tracking', 'Search', 'Detection']
}

# --- Column Generation Parameters: FIXED WINDOWS AND RANGES ---

# PRIORITY_MAP remains as is (often fixed per task type)
PRIORITY_MAP = {
    'Search': 1,
    'Detection': 2,
    'Tracking': 3,
    'Classification': 4
}
DEFAULT_PRIORITY_RANGE = (1, 5) # Fallback, though not used much with explicit map

# Request_Time Configuration
# Window for initial *tracked* target arrivals (in minutes from simulation start)
INITIAL_TRACKED_TARGET_ARRIVAL_WINDOW = (5.0, 60.0) # e.g., all 50 tracked targets appear within the first hour of simulation
# Interval for subsequent tasks for the same *tracked* target (e.g., every 30-60 seconds after the last task for that target)
SUBSEQUENT_TASK_INTERVAL_RANGE = (0.5, 1.0) # in minutes (30 to 60 seconds)

# NEW: Request_Time Configuration for Standalone Search Tasks
STANDALONE_SEARCH_ARRIVAL_WINDOW = (0.0, 180.0) # Distribute 180 search tasks over 3 hours of simulation
# Small jitter for standalone search tasks to make them less perfectly spaced
STANDALONE_SEARCH_JITTER_RANGE = (-0.5, 0.5) # +/- 0.5 minutes

# Duration Configuration (Fixed Range per Task Type)
DURATION_MAP = { # in minutes
    'Search': (1.0, 2.0),
    'Detection': (1.5, 3.0),
    'Tracking': (2.0, 4.5),
    'Classification': (3.0, 6.0)
}

# Slack for Deadline Configuration (Fixed Range per Task Type)
SLACK_FOR_DEADLINE_MAP = { # in minutes
    'Search': (5.0, 10.0),   # Plenty of slack for initial search
    'Detection': (4.0, 8.0), # Slightly less slack as target is more defined
    'Tracking': (3.0, 7.0),  # Less slack, requires continuous attention
    'Classification': (2.0, 5.0) # Tightest slack, critical to classify quickly
}

# Power Configuration (Fixed Range per Task Type)
INITIAL_POWER_MAP = { # in arbitrary power units
    'Search': (10, 25),
    'Detection': (25, 40),
    'Tracking': (40, 60),
    'Classification': (50, 75)
}
# Additional Max Power (how much more power can be allocated beyond initial)
ADDITIONAL_MAX_POWER_RANGE = (5, 20) # Max_Power will be Init_Power + random from this range

# --- Must-Drop Task Configuration ---
NUM_MUST_DROP_TASKS = 50 # At least 50 tasks to be marked as 'must-drop'
MUST_DROP_DEADLINE_REDUCTION_RANGE = (0.5, 2.0) # How many minutes before (request + duration) the deadline should be

# --- Data Generation ---
tasks_data = []
# Tracks the next available time for a new task to be requested, ensuring time progression
current_overall_simulation_time = 0.0 # Start at 0.0 minutes

# Dictionary to manage the state of each *tracked* target
# Key: Target_ID
# Value: {'current_stage': 'Search', 'stage_counts': {'Search': 0, ...}, 'last_request_time': 0.0}
tracked_target_states = {}

# --- Generate Initial Tracked Targets with their first 'Search' task ---
window_start, window_end = INITIAL_TRACKED_TARGET_ARRIVAL_WINDOW
window_duration = window_end - window_start

if NUM_UNIQUE_TRACKED_TARGETS > 1:
    average_spacing = window_duration / (NUM_UNIQUE_TRACKED_TARGETS - 1)
else:
    average_spacing = 0.0

for i in range(NUM_UNIQUE_TRACKED_TARGETS):
    target_id = i + 1 # Tracked targets start from 1
    base_arrival_time = window_start + (i * average_spacing)
    
    jitter_amount = min(average_spacing * 0.1, 1.0) # Max 1 min jitter
    target_arrival_time = base_arrival_time + random.uniform(-jitter_amount, jitter_amount)
    
    target_arrival_time = max(window_start, min(target_arrival_time, window_end))
    target_arrival_time = round(target_arrival_time, 2)

    current_overall_simulation_time = max(current_overall_simulation_time, target_arrival_time)
    
    tracked_target_states[target_id] = {
        'current_stage': 'Search',
        'stage_counts': {'Search': 0, 'Detection': 0, 'Tracking': 0, 'Classification': 0},
        'last_request_time': target_arrival_time
    }

must_drop_tasks_generated = 0
tasks_generated_count = 0

# A large enough number to ensure all progressions are usually completed,
# but with a cap to prevent infinite loops if progression logic stalls.
max_tracked_tasks_to_generate = NUM_UNIQUE_TRACKED_TARGETS * sum(MAX_STAGES_PER_TARGET_TYPE.values()) * 3 

# --- Loop to generate *Tracked Target* tasks ---
while tasks_generated_count < max_tracked_tasks_to_generate:
    
    active_targets = [tid for tid, state in tracked_target_states.items() if state['current_stage'] != 'Locked']
    
    # Break if no active targets left and enough must-drop tasks generated
    if not active_targets and must_drop_tasks_generated >= NUM_MUST_DROP_TASKS:
        break
    
    # If no active targets but we still need more must-drop tasks, pick any *tracked* target
    if not active_targets and must_drop_tasks_generated < NUM_MUST_DROP_TASKS:
        target_id = random.choice(list(tracked_target_states.keys()))
    else:
        # Randomly choose an active target to generate a task for
        target_id = random.choice(active_targets)

    target_state = tracked_target_states[target_id]
    
    current_stage_type = target_state['current_stage']
    current_stage_count = target_state['stage_counts'][current_stage_type]

    next_task_type = current_stage_type

    # Determine if the target should progress to the next stage
    if current_stage_type != 'Locked' and current_stage_count >= MAX_STAGES_PER_TARGET_TYPE[current_stage_type]:
        current_stage_index = STAGE_ORDER.index(current_stage_type)
        if current_stage_index + 1 < len(STAGE_ORDER):
            next_task_type = STAGE_ORDER[current_stage_index + 1]
            if next_task_type == 'Locked':
                target_state['current_stage'] = 'Locked'
                continue # Target is locked, no more tasks for it
            
            target_state['current_stage'] = next_task_type
    
    # If target is locked and we've generated enough must-drop tasks, skip
    if next_task_type == 'Locked' and target_state['current_stage'] == 'Locked' and must_drop_tasks_generated >= NUM_MUST_DROP_TASKS:
        continue
    
    target_state['stage_counts'][next_task_type] += 1

    # Generate a unique Task_ID for each task
    task_id = f"{target_id}_{next_task_type[0]}{target_state['stage_counts'][next_task_type]}"

    # Request_Time for tracked tasks
    if target_state['stage_counts'][next_task_type] == 1 and next_task_type == 'Search':
        # First search task uses the initial arrival time
        request_time = target_state['last_request_time']
    else:
        # Subsequent tasks for the same target have an interval after the last task
        interval_min, interval_max = SUBSEQUENT_TASK_INTERVAL_RANGE
        interval = random.uniform(interval_min, interval_max)
        request_time = target_state['last_request_time'] + interval

    # Ensure overall simulation time progresses forward
    current_overall_simulation_time = max(current_overall_simulation_time + 0.01, request_time)
    request_time = round(current_overall_simulation_time, 2)
    target_state['last_request_time'] = request_time

    # Duration
    duration_min, duration_max = DURATION_MAP.get(next_task_type)
    duration = round(random.uniform(duration_min, duration_max), 2)

    # Init_Power & Max_Power
    init_power_min, init_power_max = INITIAL_POWER_MAP.get(next_task_type)
    initial_power = random.randint(init_power_min, init_power_max)
    additional_max_power_min, additional_max_power_max = ADDITIONAL_MAX_POWER_RANGE
    max_power = initial_power + random.randint(additional_max_power_min, additional_max_power_max)

    # Must-Drop Logic and Deadline/Max_Delay
    is_must_drop = False
    if must_drop_tasks_generated < NUM_MUST_DROP_TASKS:
        is_must_drop = True
        must_drop_tasks_generated += 1

    if is_must_drop:
        reduction_amount = random.uniform(MUST_DROP_DEADLINE_REDUCTION_RANGE[0], MUST_DROP_DEADLINE_REDUCTION_RANGE[1])
        deadline = round(request_time + duration - reduction_amount, 2)
        # Ensure deadline is not before request_time + a minimal duration
        if deadline < request_time + 0.01:
            deadline = request_time + 0.01
        max_delay = 0.0 # Must-drop tasks have no allowed delay
    else:
        slack_min, slack_max = SLACK_FOR_DEADLINE_MAP.get(next_task_type)
        slack_for_deadline = random.uniform(slack_min, slack_max)
        deadline = round(request_time + duration + slack_for_deadline, 2)
        max_delay = round(deadline - request_time - duration, 2)
        if max_delay < 0: max_delay = 0.0 # Ensure max_delay is non-negative

    # Determine eligible radar type for the task
    eligible_radars = [r for r, caps in RADAR_CAPABILITIES.items() if next_task_type in caps]
    radar_type = random.choice(eligible_radars) if eligible_radars else "AnyRadar" # Fallback

    # Priority for the task type
    priority = PRIORITY_MAP.get(next_task_type, random.randint(DEFAULT_PRIORITY_RANGE[0], DEFAULT_PRIORITY_RANGE[1]))

    # Append the generated task to the list
    tasks_data.append([
        target_id, task_id, next_task_type, radar_type, priority,
        request_time, deadline, duration, initial_power, max_power, max_delay,
        target_state['stage_counts'][next_task_type]
    ])
    
    tasks_generated_count += 1

# --- NEW: Generate Standalone Search Tasks (Target_ID = 0) ---
standalone_search_tasks_generated = 0
standalone_window_start, standalone_window_end = STANDALONE_SEARCH_ARRIVAL_WINDOW
standalone_window_duration = standalone_window_end - standalone_window_start

# Distribute these 180 tasks somewhat evenly across their window
if NUM_STANDALONE_SEARCH_TASKS > 1:
    standalone_average_spacing = standalone_window_duration / (NUM_STANDALONE_SEARCH_TASKS - 1)
else:
    standalone_average_spacing = 0.0

for i in range(NUM_STANDALONE_SEARCH_TASKS):
    target_id = 0 # As requested, Target_ID = 0 for these tasks
    task_type = 'Search' # Always 'Search'

    # Calculate request time
    base_request_time = standalone_window_start + (i * standalone_average_spacing)
    request_time_jitter = random.uniform(STANDALONE_SEARCH_JITTER_RANGE[0], STANDALONE_SEARCH_JITTER_RANGE[1])
    request_time = base_request_time + request_time_jitter
    
    request_time = max(standalone_window_start, min(request_time, standalone_window_end)) # Keep within window
    request_time = round(request_time, 2)

    # Ensure overall simulation time progresses, even if these are generated out of order
    current_overall_simulation_time = max(current_overall_simulation_time, request_time + 0.01) # Small increment

    # Duration for Search tasks
    duration_min, duration_max = DURATION_MAP['Search']
    duration = round(random.uniform(duration_min, duration_max), 2)

    # Init_Power & Max_Power for Search tasks
    init_power_min, init_power_max = INITIAL_POWER_MAP['Search']
    initial_power = random.randint(init_power_min, init_power_max)
    additional_max_power_min, additional_max_power_max = ADDITIONAL_MAX_POWER_RANGE
    max_power = initial_power + random.randint(additional_max_power_min, additional_max_power_max)

    # Slack for Deadline for Search tasks
    slack_min, slack_max = SLACK_FOR_DEADLINE_MAP['Search']
    slack_for_deadline = random.uniform(slack_min, slack_max)
    deadline = round(request_time + duration + slack_for_deadline, 2)
    
    max_delay = round(deadline - request_time - duration, 2)
    if max_delay < 0: max_delay = 0.0

    # Radar Type for Search tasks
    eligible_radars_for_search = [r for r, caps in RADAR_CAPABILITIES.items() if 'Search' in caps]
    radar_type = random.choice(eligible_radars_for_search) if eligible_radars_for_search else "AnyRadar"

    # Priority for Search tasks
    priority = PRIORITY_MAP['Search']
    
    # Task ID for standalone searches: use a specific prefix
    standalone_search_tasks_generated += 1
    task_id = f"SA_S{standalone_search_tasks_generated}" # Standalone Search Task ID

    # Append the generated standalone task to the list
    tasks_data.append([
        target_id, task_id, task_type, radar_type, priority,
        request_time, deadline, duration, initial_power, max_power, max_delay,
        1 # Stage_Count is always 1 for these standalone searches
    ])

# --- Final Sort by Request_Time to ensure chronological order in CSV ---
tasks_data.sort(key=lambda x: x[5]) # Sort by Request_Time column

# --- Write to CSV ---
csv_file_name = 'radar_tasks_with_standalone_searches.csv'
headers = [
    'Target_ID', 'Task_ID', 'Task_Type', 'Radar_Type', 'Priority',
    'Request_Time', 'Deadline', 'Duration', 'Init_Power',
    'Max_Power', 'Max_Delay', 'Stage_Count'
]

try:
    with open(csv_file_name, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(headers)
        writer.writerows(tasks_data)
    print(f"CSV file '{csv_file_name}' generated successfully with {len(tasks_data)} tasks.")
    # The following print statements are commented out as they might generate too much output
    # print(f"Total tracked target tasks generated: {tasks_generated_count}.")
    # print(f"Total standalone search tasks generated: {standalone_search_tasks_generated}.")
    # print(f"Number of 'must-drop' tasks generated: {must_drop_tasks_generated}.")

except IOError:
    print(f"Error: Could not write to file '{csv_file_name}'. Please check permissions.")


# --- Pygame Visualization ---

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 800 # Smaller width
SCREEN_HEIGHT = 550 # Smaller height
RADAR_WIDTH = 500 # Adjusted width dedicated to the radar display
INFO_PANEL_WIDTH = SCREEN_WIDTH - RADAR_WIDTH # Width of the information panel
INFO_PANEL_X = RADAR_WIDTH # X-coordinate where the info panel starts

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Realtime Radar Simulation")

# Colors (RGB tuples)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
GRAY = (200, 200, 200)
DARK_GRAY = (100, 100, 100)
BLUE = (0, 0, 255)
RED = (255, 0, 0)
ORANGE = (255, 165, 0)
PURPLE = (128, 0, 128)
CYAN = (0, 255, 255)
MAGENTA = (255, 0, 255) # Added for potential future use or variety

# Fonts
font_large = pygame.font.Font(None, 30) # Adjusted font size for smaller window
font_medium = pygame.font.Font(None, 22) # Adjusted font size
font_small = pygame.font.Font(None, 18) # Adjusted font size for readability of tasks

# Radar properties
RADAR_CENTER_X = RADAR_WIDTH // 2
RADAR_CENTER_Y = SCREEN_HEIGHT // 2
RADAR_RADIUS = 180 # Even smaller radar radius

# Radar sweep animation
sweep_angle = 0 # Current angle of the radar sweep line in degrees
sweep_speed = 0.5 # Speed of the sweep rotation in degrees per frame

# Simulation time
current_simulation_time_minutes = 0.0 # The current time in the simulation, in minutes
simulation_speed_multiplier = 1.0 # Controls how fast simulation time progresses (e.g., 2.0 means 2x speed)
is_playing = True # State for play/pause functionality

# --- Load and Parse Task Data from CSV ---
parsed_tasks = []
try:
    with open(csv_file_name, 'r', newline='') as file:
        reader = csv.DictReader(file) # Use DictReader to read rows as dictionaries
        for row in reader:
            # Convert relevant fields to appropriate data types
            row['Target_ID'] = int(row['Target_ID'])
            row['Priority'] = int(row['Priority'])
            row['Request_Time'] = float(row['Request_Time'])
            row['Deadline'] = float(row['Deadline'])
            row['Duration'] = float(row['Duration'])
            row['Init_Power'] = int(row['Init_Power'])
            row['Max_Power'] = int(row['Max_Power'])
            row['Max_Delay'] = float(row['Max_Delay'])
            row['Stage_Count'] = int(row['Stage_Count'])
            parsed_tasks.append(row)
    print(f"Successfully loaded {len(parsed_tasks)} tasks from '{csv_file_name}'.")
except FileNotFoundError:
    print(f"Error: CSV file '{csv_file_name}' not found. Please ensure data generation completed successfully.")
    # Exit Pygame or handle gracefully if data isn't available
    pygame.quit()
    exit()
except Exception as e:
    print(f"Error parsing CSV file: {e}")
    pygame.quit()
    exit()


# Determine the maximum simulation time for the slider (based on the latest deadline)
max_sim_time = 0.0
if parsed_tasks: # Ensure there are tasks to avoid error
    max_sim_time = max(task['Deadline'] for task in parsed_tasks)
else:
    max_sim_time = 1.0 # Default to 1 minute if no tasks for a valid slider range

# Slider properties for scrubbing through simulation time
SLIDER_X = INFO_PANEL_X + 20
SLIDER_Y = SCREEN_HEIGHT - 60 # Position near the bottom of the info panel
SLIDER_WIDTH = INFO_PANEL_WIDTH - 40
SLIDER_HEIGHT = 20
SLIDER_HANDLE_WIDTH = 10
SLIDER_HANDLE_COLOR = BLUE

# Play/Pause button properties
PLAY_PAUSE_BUTTON_RECT = pygame.Rect(SLIDER_X, SLIDER_Y - 40, 100, 30)

# Fast Forward button properties
FAST_FORWARD_BUTTON_RECT = pygame.Rect(SLIDER_X + 120, SLIDER_Y - 40, 100, 30)

# Task shape and color mapping for radar visualization
TASK_SHAPES = {
    'Search': 'circle',
    'Detection': 'large_circle', # Slightly larger circle to distinguish from 'Search'
    'Tracking': 'square',
    'Classification': 'triangle'
}

TASK_COLORS = {
    'Search': CYAN,
    'Detection': ORANGE,
    'Tracking': PURPLE,
    'Classification': RED
}

# Dictionary to store target positions on radar to keep them consistent once detected
# Key: Target_ID, Value: {'x': ..., 'y': ...}
target_positions = {}

# Scroll offset for the information panel (if too many tasks to display at once)
scroll_offset_y = 0
# MAX_DISPLAYED_TASKS is now dynamically calculated based on available height and line_height

# --- Helper Functions for Drawing ---

def draw_radar_elements(surf):
    """Draws the concentric circles and crosshairs of the radar."""
    # Draw radar circles
    pygame.draw.circle(surf, BLACK, (RADAR_CENTER_X, RADAR_CENTER_Y), RADAR_RADIUS, 2)
    pygame.draw.circle(surf, BLACK, (RADAR_CENTER_X, RADAR_CENTER_Y), RADAR_RADIUS * 2 // 3, 2)
    pygame.draw.circle(surf, BLACK, (RADAR_CENTER_X, RADAR_CENTER_Y), RADAR_RADIUS // 3, 2)

    # Draw crosshairs (horizontal and vertical lines)
    pygame.draw.line(surf, BLACK, (RADAR_CENTER_X, RADAR_CENTER_Y - RADAR_RADIUS),
                     (RADAR_CENTER_X, RADAR_CENTER_Y + RADAR_RADIUS), 2)
    pygame.draw.line(surf, BLACK, (RADAR_CENTER_X - RADAR_RADIUS, RADAR_CENTER_Y),
                     (RADAR_CENTER_X + RADAR_RADIUS, RADAR_CENTER_Y), 2)

def draw_target(surf, target_id, task_type, x, y):
    """Draws a target on the radar with a specific shape and color."""
    color = TASK_COLORS.get(task_type, BLACK) # Get color based on task type, default to black
    shape = TASK_SHAPES.get(task_type, 'circle') # Get shape based on task type, default to circle
    
    # Draw the shape based on the task type
    if shape == 'circle':
        radius = 5 # Smaller radius for Search
        pygame.draw.circle(surf, color, (x, y), radius)
    elif shape == 'large_circle':
        radius = 8 # Larger radius for Detection
        pygame.draw.circle(surf, color, (x, y), radius)
    elif shape == 'square':
        size = 12
        pygame.draw.rect(surf, color, (x - size // 2, y - size // 2, size, size))
    elif shape == 'triangle':
        size = 15
        # Calculate triangle points (equilateral triangle pointing up)
        points = [(x, y - size // 2), (x - size // 2, y + size // 2), (x + size // 2, y + size // 2)]
        pygame.draw.polygon(surf, color, points)
    
    # Re-added: Draw Target_ID label only for tracked targets (Target_ID != 0)
    if target_id != 0:
        text_surface = font_small.render(f"{target_id}", True, BLACK)
        surf.blit(text_surface, (x + 10, y - 10)) # Offset label slightly for visibility


def draw_slider(surf, value, min_val, max_val):
    """Draws a horizontal slider to control the simulation time."""
    # Draw slider track (the background bar)
    pygame.draw.rect(surf, DARK_GRAY, (SLIDER_X, SLIDER_Y, SLIDER_WIDTH, SLIDER_HEIGHT), border_radius=5)
    
    # Calculate slider handle position based on current value
    if max_val == min_val: # Avoid division by zero if range is zero
        handle_x = SLIDER_X
    else:
        normalized_value = (value - min_val) / (max_val - min_val)
        # Position handle within the slider track, accounting for handle width
        handle_x = SLIDER_X + normalized_value * (SLIDER_WIDTH - SLIDER_HANDLE_WIDTH)
    
    # Draw slider handle (the draggable part)
    handle_rect = pygame.Rect(handle_x, SLIDER_Y, SLIDER_HANDLE_WIDTH, SLIDER_HEIGHT)
    pygame.draw.rect(surf, SLIDER_HANDLE_COLOR, handle_rect, border_radius=3)

    # Display current simulation time as text below the slider
    time_text = font_small.render(f"Time: {value:.2f} min", True, BLACK)
    surf.blit(time_text, (SLIDER_X + SLIDER_WIDTH / 2 - time_text.get_width() / 2, SLIDER_Y + SLIDER_HEIGHT + 5))

def draw_button(surf, rect, text, color, text_color=BLACK):
    """Draws a button with text."""
    pygame.draw.rect(surf, color, rect, border_radius=5) # Draw button rectangle
    text_surf = font_small.render(text, True, text_color) # Render button text
    text_rect = text_surf.get_rect(center=rect.center) # Center text within button
    surf.blit(text_surf, text_rect) # Blit text onto the button

def draw_shape_legend(surf, x, y, font):
    """Draws a legend for task shapes and colors."""
    legend_title = font_medium.render("Task Type Legend:", True, BLACK)
    surf.blit(legend_title, (x, y))
    current_y = y + legend_title.get_height() + 5

    # Define the order for the legend
    legend_order = ['Search', 'Detection', 'Tracking', 'Classification']

    for task_type in legend_order:
        shape_name = TASK_SHAPES.get(task_type)
        color = TASK_COLORS.get(task_type)
        
        # Draw the shape in a small area for the legend
        shape_center_x = x + 15
        shape_center_y = current_y + 10 # Offset for drawing
        
        if shape_name == 'circle': # For Search
            radius = 5
            pygame.draw.circle(surf, color, (shape_center_x, shape_center_y), radius)
            label_text = f"Search" # No shape name in text
        elif shape_name == 'large_circle': # For Detection
            radius = 8 
            pygame.draw.circle(surf, color, (shape_center_x, shape_center_y), radius)
            label_text = f"Detection" # No shape name in text
        elif shape_name == 'square': # For Tracking
            size = 12
            pygame.draw.rect(surf, color, (shape_center_x - size // 2, shape_center_y - size // 2, size, size))
            label_text = f"Tracking" # No shape name in text
        elif shape_name == 'triangle': # For Classification
            size = 15
            points = [(shape_center_x, shape_center_y - size // 2 +2), (shape_center_x - size // 2, shape_center_y + size // 2 +2), (shape_center_x + size // 2, shape_center_y + size // 2 +2)]
            pygame.draw.polygon(surf, color, points)
            label_text = f"Classification" # No shape name in text
        else:
            continue # Skip if shape_name is not recognized

        label_surface = font.render(label_text, True, BLACK)
        surf.blit(label_surface, (x + 30, current_y)) # Position label next to shape
        current_y += 25 # Move down for next legend item

    return current_y # Return the y-position after the legend for further elements


# --- Main Game Loop ---
running = True # Flag to keep the game loop running
clock = pygame.time.Clock() # Pygame clock to control frame rate

while running:
    # Event handling loop
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            # If user clicks the close button, set running to False to exit loop
            running = False
        
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1: # Left mouse click
                # Check if slider was clicked
                if SLIDER_X <= event.pos[0] <= SLIDER_X + SLIDER_WIDTH and \
                   SLIDER_Y <= event.pos[1] <= SLIDER_Y + SLIDER_HEIGHT:
                    is_playing = False # Pause simulation when user starts scrubbing
                    # Calculate new simulation time based on click position
                    normalized_pos = (event.pos[0] - SLIDER_X) / SLIDER_WIDTH
                    current_simulation_time_minutes = normalized_pos * max_sim_time
                
                # Check if Play/Pause button was clicked
                if PLAY_PAUSE_BUTTON_RECT.collidepoint(event.pos):
                    is_playing = not is_playing # Toggle play/pause state
                
                # Check if Fast Forward button was clicked
                if FAST_FORWARD_BUTTON_RECT.collidepoint(event.pos):
                    simulation_speed_multiplier *= 2.0 # Double the simulation speed
                    if simulation_speed_multiplier > 16.0: # Cap the speed to avoid excessive values
                        simulation_speed_multiplier = 1.0 # Reset to normal speed after max cap

        if event.type == pygame.MOUSEMOTION:
            if pygame.mouse.get_pressed()[0]: # If left mouse button is held down
                # If mouse is over the slider and being dragged, update simulation time
                if SLIDER_X <= event.pos[0] <= SLIDER_X + SLIDER_WIDTH and \
                   SLIDER_Y <= event.pos[1] <= SLIDER_Y + SLIDER_HEIGHT:
                    normalized_pos = (event.pos[0] - SLIDER_X) / SLIDER_WIDTH
                    current_simulation_time_minutes = normalized_pos * max_sim_time
        
        # Handle scrolling for the info panel (if content overflows)
        if event.type == pygame.MOUSEBUTTONDOWN:
            if INFO_PANEL_X < event.pos[0] < SCREEN_WIDTH: # Only scroll if mouse is in info panel area
                if event.button == 4: # Scroll wheel up
                    scroll_offset_y = max(0, scroll_offset_y - 20) # Scroll up by 20 pixels
                elif event.button == 5: # Scroll wheel down
                    scroll_offset_y += 20 # Scroll down by 20 pixels

    # --- Drawing Phase ---
    screen.fill(WHITE) # Fill the entire screen with white background

    # Create a surface for the radar area to keep it separate from info panel
    radar_surf = pygame.Surface((RADAR_WIDTH, SCREEN_HEIGHT))
    radar_surf.fill(WHITE) # Fill radar surface with white background
    
    draw_radar_elements(radar_surf) # Draw fixed radar components

    # Update and draw radar sweep line only if playing
    if is_playing:
        sweep_angle = (sweep_angle + sweep_speed) % 360 # Rotate the sweep line
    # Calculate end point of the sweep line using trigonometry
    end_x = RADAR_CENTER_X + RADAR_RADIUS * math.cos(math.radians(sweep_angle))
    end_y = RADAR_CENTER_Y - RADAR_RADIUS * math.sin(math.radians(sweep_angle)) # Pygame y-axis is inverted
    pygame.draw.line(radar_surf, GREEN, (RADAR_CENTER_X, RADAR_CENTER_Y), (end_x, end_y), 3)

    # Display active targets on the radar
    for task in parsed_tasks:
        # Check if task is active within the current simulation time
        if task['Request_Time'] <= current_simulation_time_minutes <= task['Deadline']:
            
            target_id = task['Target_ID']
            task_type = task['Task_Type'] # Get task type for drawing shape/color
            
            # For standalone searches (Target_ID 0), assign a fixed random position
            # This ensures they appear consistently once their request time is met
            if target_id == 0:
                # Use Task_ID to ensure unique positions for each standalone search task
                unique_key = task['Task_ID'] 
            else:
                # For tracked targets, use Target_ID for consistent positions
                unique_key = target_id

            if unique_key not in target_positions:
                # If target/task is new, assign a random fixed position within the radar
                angle = random.uniform(0, 2 * math.pi) # Random angle
                distance_factor = random.uniform(0.3, 1.0) # Random distance from center (30% to 100% of radius)
                dist = RADAR_RADIUS * distance_factor
                
                pos_x = RADAR_CENTER_X + dist * math.cos(angle)
                pos_y = RADAR_CENTER_Y - dist * math.sin(angle) # Adjust for Pygame y-axis
                
                target_positions[unique_key] = {'x': pos_x, 'y': pos_y} # Store fixed position
            
            pos = target_positions[unique_key]
            # Draw target with Target_ID label if it's a tracked target
            draw_target(radar_surf, target_id, task_type, int(pos['x']), int(pos['y']))
    
    # Draw the legend on the radar_surf (left side)
    # Position: X=10, Y near bottom of radar_surf
    # Adjusted legend_start_y_on_radar for smaller window
    legend_start_y_on_radar = SCREEN_HEIGHT - 120 # Adjust as needed for total legend height
    draw_shape_legend(radar_surf, 10, legend_start_y_on_radar, font_small)

    screen.blit(radar_surf, (0, 0)) # Blit the radar surface onto the main screen

    # --- Draw Info Panel Area ---
    pygame.draw.rect(screen, GRAY, (INFO_PANEL_X, 0, INFO_PANEL_WIDTH, SCREEN_HEIGHT)) # Background for info panel
    
    # Title for the info panel
    title_text = font_large.render("Active Tasks", True, BLACK)
    screen.blit(title_text, (INFO_PANEL_X + (INFO_PANEL_WIDTH - title_text.get_width()) // 2, 10))

    # Display tasks that are currently "active" (request time <= current sim time <= deadline)
    # The list of active tasks is populated here
    all_active_tasks = []
    for task in parsed_tasks:
        if task['Request_Time'] <= current_simulation_time_minutes <= task['Deadline']:
            all_active_tasks.append(task)

    # Calculate max scroll offset based on number of active tasks
    # Info panel tasks start higher now as legend is moved
    info_panel_start_y = 50 # Starting Y position for task list, can be higher now
    line_height = 25 # Keep line height consistent for readability

    total_tasks_height = len(all_active_tasks) * line_height 
    display_area_height = SCREEN_HEIGHT - info_panel_start_y - SLIDER_HEIGHT - 100 # Area available for tasks above slider/buttons
    max_scroll_y = max(0, total_tasks_height - display_area_height)
    scroll_offset_y = min(scroll_offset_y, max_scroll_y) # Prevent scrolling too far down

    # Iterate through active tasks and draw them in the info panel
    display_count = 0
    for i, task in enumerate(all_active_tasks):
        # Calculate Y position, applying scroll offset
        y_pos = info_panel_start_y + i * line_height - scroll_offset_y
        
        # Only draw tasks that are within the visible area of the info panel
        if y_pos < info_panel_start_y - line_height or y_pos + line_height > SCREEN_HEIGHT - 100 + line_height:
            continue

        # Format task information for display - ONLY others (Radar, Priority, Req, Deadline)
        task_info_str = (
            f"ID: {task['Task_ID']}, "
            f"{task['Radar_Type']}, Priority: {task['Priority']}, "
            f"Rq T: {task['Request_Time']:.1f}, DDL: {task['Deadline']:.1f}"
        )
        task_text_surface = font_small.render(task_info_str, True, BLACK)
        screen.blit(task_text_surface, (INFO_PANEL_X + 10, y_pos))
        display_count += 1
            
    # Draw the slider and control buttons
    draw_slider(screen, current_simulation_time_minutes, 0, max_sim_time)
    draw_button(screen, PLAY_PAUSE_BUTTON_RECT, "Pause" if is_playing else "Play", GREEN if is_playing else BLUE)
    draw_button(screen, FAST_FORWARD_BUTTON_RECT, f"FF x{simulation_speed_multiplier:.0f}", ORANGE)

    # Update simulation time if playing
    if is_playing:
        delta_time = clock.get_time() / 1000.0 / 60.0 # Convert milliseconds per frame to minutes per frame
        current_simulation_time_minutes += delta_time * simulation_speed_multiplier
        
        # Loop the simulation when it reaches the end
        if current_simulation_time_minutes > max_sim_time:
            current_simulation_time_minutes = 0.0 # Reset to beginning

    # Update the full display
    pygame.display.flip()
    
    # Control frame rate to 60 FPS
    clock.tick(60) 

# Quit Pygame when the loop finishes
pygame.quit()
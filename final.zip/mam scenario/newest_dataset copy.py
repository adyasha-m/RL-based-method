import csv
import random

# --- Configuration ---
NUM_UNIQUE_TARGETS = 50 # Number of distinct targets to simulate
# Maximum number of times a target can be processed for each specific stage.
# This ensures we generate enough tasks for a target to 'qualify' for the next stage.
MAX_STAGES_PER_TARGET_TYPE = {
    'Search': 1,        # 1 Search task is enough to potentially move to Detection
    'Detection': 4,     # Need 4 Detection tasks to move to Tracking
    'Tracking': 5,      # Need 5 Tracking tasks to move to Classification
    'Classification': 6 # Need 6 Classification tasks for 'Target Locked'
}
# Define the order of progression
STAGE_ORDER = ['Search', 'Detection', 'Tracking', 'Classification', 'Locked']

# Radar capabilities: Which tasks each radar can perform
RADAR_CAPABILITIES = {
    'Radar1': ['Search', 'Detection', 'Classification'],
    'Radar2': ['Classification', 'Tracking', 'Detection'],
    'Radar3': ['Tracking', 'Search', 'Detection']
}

# --- Column Generation Parameters ---
PRIORITY_MAP = {
    'Search': 1,
    'Detection': 2,
    'Tracking': 3,
    'Classification': 4
}
DEFAULT_PRIORITY_RANGE = (1, 5)

INITIAL_REQUEST_TIME = 0.0
AVG_TARGET_ARRIVAL_INTERVAL = 5.0 # Average time between initial target appearances

DURATION_MAP = {
    'Search': (1, 3),
    'Detection': (2, 4),
    'Tracking': (3, 6),
    'Classification': (4, 8)
}

SLACK_FOR_DEADLINE_MAP = {
    'Search': (5, 15),
    'Detection': (4, 12),
    'Tracking': (3, 10),
    'Classification': (2, 8)
}

INITIAL_POWER_MAP = {
    'Search': (10, 20),
    'Detection': (20, 35),
    'Tracking': (30, 45),
    'Classification': (40, 60)
}

ADDITIONAL_MAX_POWER_RANGE = (0, 15)

# --- Must-Drop Task Configuration ---
NUM_MUST_DROP_TASKS = 50 # At least 50 tasks to be marked as 'must-drop'
must_drop_tasks_generated = 0

# --- Data Generation ---
tasks_data = []
# Tracks the next available time for a new task to be requested, ensuring time progression
current_overall_simulation_time = INITIAL_REQUEST_TIME

# Dictionary to manage the state of each target
# Key: Target_ID
# Value: {'current_stage': 'Search', 'stage_counts': {'Search': 0, ...}, 'last_request_time': 0.0}
target_states = {}

# Initialize all unique targets with their first 'Search' task
for i in range(NUM_UNIQUE_TARGETS):
    target_id = i + 1
    
    # Calculate initial arrival time for the target
    if i == 0:
        target_arrival_time = INITIAL_REQUEST_TIME
    else:
        time_increment = random.uniform(
            0.8 * AVG_TARGET_ARRIVAL_INTERVAL,
            1.2 * AVG_TARGET_ARRIVAL_INTERVAL
        )
        current_overall_simulation_time += time_increment
        target_arrival_time = round(current_overall_simulation_time, 2)
    
    target_states[target_id] = {
        'current_stage': 'Search',
        'stage_counts': {'Search': 0, 'Detection': 0, 'Tracking': 0, 'Classification': 0},
        'last_request_time': target_arrival_time
    }

# Loop to generate tasks until all targets have progressed as much as possible
# We'll set a generous upper bound for the number of tasks to generate.
# Each target generates a minimum of 1 task, and a maximum of (1+4+5+6) = 16 tasks to be 'Locked'.
# So, NUM_UNIQUE_TARGETS * 16 is a reasonable maximum.
for _ in range(NUM_UNIQUE_TARGETS * sum(MAX_STAGES_PER_TARGET_TYPE.values()) * 2): # Increased upper bound for more tasks
    
    # Find active targets that haven't reached 'Locked' state
    active_targets = [tid for tid, state in target_states.items() if state['current_stage'] != 'Locked']
    
    if not active_targets and must_drop_tasks_generated >= NUM_MUST_DROP_TASKS:
        break # All targets have reached their final state and enough must-drop tasks generated

    # Select a random active target to generate a task for
    target_id = random.choice(active_targets) if active_targets else random.choice(list(target_states.keys())) # If no active, pick any to generate a task, potentially a must-drop

    target_state = target_states[target_id]
    
    current_stage_type = target_state['current_stage']
    current_stage_count = target_state['stage_counts'][current_stage_type]

    next_task_type = current_stage_type # Assume we generate a task for the current stage first

    # Check if the current stage has been 'completed' enough times to move to the next logical stage
    if current_stage_type != 'Locked' and current_stage_count >= MAX_STAGES_PER_TARGET_TYPE[current_stage_type]:
        current_stage_index = STAGE_ORDER.index(current_stage_type)
        if current_stage_index + 1 < len(STAGE_ORDER):
            next_task_type = STAGE_ORDER[current_stage_index + 1]
            if next_task_type == 'Locked':
                target_state['current_stage'] = 'Locked' # Mark target as locked
                continue # Skip task generation for locked targets
            
            # Reset stage count for the new type, but increment the overall type count
            target_state['current_stage'] = next_task_type
            # We don't reset the count for the NEW stage, we just start counting for it.
            # The next line will increment it from 0.

    # Increment the count for the task type we are about to generate
    if next_task_type != 'Locked': # Only increment if it's a real task type
        target_state['stage_counts'][next_task_type] += 1
    else:
        continue # Don't generate a task if the target is locked

    # Generate Task ID
    task_id = f"{target_id}_{next_task_type[0]}{target_state['stage_counts'][next_task_type]}"

    # Calculate Request Time for the new task.
    # It should be at or after the last task's request time for this target.
    # We also ensure overall simulation time progresses.
    request_time = max(target_state['last_request_time'], current_overall_simulation_time)
    
    # Update overall simulation time for future tasks
    current_overall_simulation_time = request_time + random.uniform(0.1, 1.0) # Small increment to ensure progression

    # Get parameters based on the current task type
    duration_range = DURATION_MAP.get(next_task_type, (2, 8))
    duration = random.randint(duration_range[0], duration_range[1])

    # --- Must-Drop Task Logic ---
    is_must_drop = False
    if must_drop_tasks_generated < NUM_MUST_DROP_TASKS:
        # Decide to make this task a must-drop (e.g., 20% chance or if we still need more)
        # To ensure we hit NUM_MUST_DROP_TASKS, we'll make it always true until we reach the count
        is_must_drop = True
        must_drop_tasks_generated += 1

    if is_must_drop:
        # Make the deadline impossible: duration > (deadline - request_time)
        # This means deadline < request_time + duration
        # We'll set deadline to be slightly less than request_time + duration
        deadline = round(request_time + duration - random.uniform(0.1, 2.0), 2)
        # Ensure deadline doesn't go below request_time for logical consistency, though it won't matter for impossibility
        if deadline < request_time:
            deadline = request_time + 0.1 # Smallest possible positive deadline to maintain some order
        
        # Override slack and max_delay to reflect impossibility
        slack_for_deadline = round(deadline - request_time - duration, 2) # This will be negative
        max_delay = 0.0 # It's impossible to delay, so max_delay is 0 by definition (or negative if we allow it)
    else:
        slack_range = SLACK_FOR_DEADLINE_MAP.get(next_task_type, (3, 10))
        slack_for_deadline = random.randint(slack_range[0], slack_range[1])
        deadline = round(request_time + duration + slack_for_deadline, 2)
        max_delay = round(deadline - request_time - duration, 2)
        if max_delay < 0: max_delay = 0.0 # Clamp max_delay to 0 if it somehow becomes negative (shouldn't happen with positive slack)


    initial_power_range = INITIAL_POWER_MAP.get(next_task_type, (10, 50))
    initial_power = random.randint(initial_power_range[0], initial_power_range[1])
    max_power = initial_power + random.randint(ADDITIONAL_MAX_POWER_RANGE[0], ADDITIONAL_MAX_POWER_RANGE[1])

    # Determine eligible radars for the task type
    eligible_radars = [r for r, caps in RADAR_CAPABILITIES.items() if next_task_type in caps]
    radar_type = random.choice(eligible_radars) if eligible_radars else "AnyRadar"

    priority = PRIORITY_MAP.get(next_task_type, random.randint(DEFAULT_PRIORITY_RANGE[0], DEFAULT_PRIORITY_RANGE[1]))

    # Add the generated task to the list
    tasks_data.append([
        target_id, task_id, next_task_type, radar_type, priority,
        request_time, deadline, duration, initial_power, max_power, max_delay,
        target_state['stage_counts'][next_task_type]
    ])
    
    # Update the last request time for this target
    target_state['last_request_time'] = request_time

# --- Write to CSV ---
csv_file_name = 'dynamic_radar_tasks_full_progression_with_must_drop.csv'
headers = [
    'Target_ID', 'Task_ID', 'Task_Type', 'Radar_Type', 'Priority',
    'Request_Time', 'Deadline', 'Duration', 'Init_Power',
    'Max_Power', 'Max_Delay', 'Stage_Count'
]

try:
    with open(csv_file_name, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(headers)
        writer.writerows(tasks_data)
    print(f"CSV file '{csv_file_name}' generated successfully with {len(tasks_data)} tasks.")
    print(f"Number of 'must-drop' tasks generated: {must_drop_tasks_generated}")


    print("\nFirst 20 tasks generated (showing progression examples and potential must-drops):")
    # Sort by Target_ID and then Request_Time to see progression clearly
    sorted_tasks = sorted(tasks_data, key=lambda x: (x[0], x[5]))
    for row in sorted_tasks[:20]:
        # Add a flag to easily identify must-drop tasks for printing
        is_must_drop_print = "YES" if row[7] > (row[6] - row[5]) else "NO" # Duration > (Deadline - Request_Time)
        row_dict = dict(zip(headers, row))
        row_dict['Is_Must_Drop'] = is_must_drop_print
        print(row_dict)

except IOError:
    print(f"Error: Could not write to file '{csv_file_name}'. Please check permissions.")